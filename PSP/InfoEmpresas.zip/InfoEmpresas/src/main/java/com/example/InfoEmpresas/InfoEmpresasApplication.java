package com.example.InfoEmpresas;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class InfoEmpresasApplication {

	public static void main(String[] args) {
		SpringApplication.run(InfoEmpresasApplication.class, args);
	}

}
